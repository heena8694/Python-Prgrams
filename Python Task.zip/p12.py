# program 23 :
# Write a method which can calculate square value of number
# Hints:
# Using the ** operator
def square_number(number):
    return number **2
num = int(input("Enter a number"))
sqr = square_number(num)
print(sqr)