# program 44 :

# Write a program which accepts a string as input to print "Yes"
# if the string is "yes" or "YES" or "Yes", otherwise print "No".

# Hints:
# Use if statement to judge condition.

txt = input("Enter a String")
if txt == "yes" or txt == "YES" or txt == "Yes":
    print("Yes")
else:
    print("NO")