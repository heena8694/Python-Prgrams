# program 27 :
# Define a function that can convert a integer
# into a string and print it in console.
# Hints:
# Use str() to convert a number to string.
def int_to_string(num):
    print(str(num))

int_to_string(1234)